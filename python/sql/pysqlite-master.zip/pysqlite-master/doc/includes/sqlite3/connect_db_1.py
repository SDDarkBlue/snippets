from pysqlite2 import dbapi2 as sqlite3

con = sqlite3.connect("mydb")
